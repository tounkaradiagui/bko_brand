@extends('layouts.app')

@section('title', 'Liste de Souhait')
@section('content')

<livewire:frontend.wishlist-show/>

@endsection