@extends('layouts.app')

@section('title', "Inscription - Nouvel utilisateur !")
@section('content')

  <livewire:frontend.signup>
@endsection
