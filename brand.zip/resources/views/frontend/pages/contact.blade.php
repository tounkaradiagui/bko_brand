@extends('layouts.app')
@section('content')
@section('title', 'Contacter Golden Market')

<livewire:contact-show>

@endsection
