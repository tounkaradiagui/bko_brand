@extends('layouts.app')

@section('title', 'Liste de Panier')
@section('content')

<livewire:frontend.cart.cart-show/>

@endsection