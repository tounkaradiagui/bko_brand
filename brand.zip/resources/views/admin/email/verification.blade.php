@extends('layouts.app')

@section('title', 'Vérification - adresse - email')

@section('content')

hello

@endsection
