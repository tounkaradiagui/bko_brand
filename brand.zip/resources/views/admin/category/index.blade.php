@extends('layouts.admin')

@section('title', 'Liste de catégories')

@section('content')

<div>
    <livewire:admin.category.index/>
</div>

@endsection()
