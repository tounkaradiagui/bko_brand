@extends('layouts.admin')
@section('title', 'Mail reçu')
@section('content')

hello

@endsection