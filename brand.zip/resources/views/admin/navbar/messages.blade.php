@extends('layouts.admin')
@section('title', 'Messages')
@section('content')


<livewire:admin.navbar.message-show>

@endsection
