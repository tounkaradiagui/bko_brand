import About from "./components/About.vue";

export default [
    {
        path: '/a-propos-de-nous',
        name: 'about',
        component: About,
    }
]

