<div>
    <div>
        <?php echo $__env->make('livewire.admin.brand.modal-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>
                            La liste de marques
                            <input type="search" wire:model="search" class="form-control float-end max-2" placeholder="Rechercher une marque ici !" style="width:220px; border-radius">
                            <a href="#" class="btn btn-primary btn-sm float-end mr-3" data-bs-toggle="modal" data-bs-target="#ajoutModal" title="Ajouter"><i class="mdi mdi-plus"></i></a>
                        </h4>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Nom de la marque</th>
                                    <th>Catégorie</th>
                                    <th>Slug</th>
                                    <th>Status</th>
                                    <th colspan="2">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($brand->nom); ?></td>
                                    <td>
                                        <?php if($brand->category): ?>
                                            <?php echo e($brand->category->name); ?>

                                        <?php else: ?>
                                            Aucune catégorie associée à la marque <?php echo e($brand->nom); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($brand->slug); ?></td>
                                    <td><?php echo e($brand->status =='1' ? 'masquer':'visible'); ?></td>
                                    <td> <a href="#" wire:click="editBrand(<?php echo e($brand->id); ?>)" data-bs-toggle="modal" data-bs-target="#updateBrandModal" class="btn btn-success btn-sm" title="Modifier"><i class="mdi mdi-pen"></i> </td>
                                    <td><a href="#" wire:click="deleteBrand(<?php echo e($brand->id); ?>)" class="btn btn-danger btn-sm " data-bs-toggle="modal" data-bs-target="#deleteBrandModal" title="Supprimer"><i class="mdi mdi-delete"></i></a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">Aucune marque trouvée</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div>
                            <?php echo e($brands->links()); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
    <script>
            window.addEventListener('close-modal', event => {

            $('#ajoutModal').modal('hide');
            $('#updateBrandModal').modal('hide');
            $('#deleteBrandModal').modal('hide');

            });
    </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/livewire/admin/brand/index.blade.php ENDPATH**/ ?>