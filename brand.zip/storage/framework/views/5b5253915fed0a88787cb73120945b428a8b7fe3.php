<?php $__env->startSection('title', "Merci d'avoir acheté nos produits !"); ?>
<?php $__env->startSection('content'); ?>

    <div class="py-3 pyt-md-4">

        <div class="container">

            <div class="row">

                <div class="col-md-12 text-center">
                    <?php if(session('message')): ?>
                        <h5 class="alert alert-success"><?php echo e(session('message')); ?></h5>
                    <?php endif; ?>
                    <div class="p-4 shadow bg-white">
                        <h2>
                            <img src="<?php echo e(asset('admin/images/logogolden.png')); ?>" title="Diagui Shop"  alt="Diagui Shop" width="500px" height="400px">
                        </h2>
                        <h4>Merci pour vos achats avec Diagui Shop</h4>
                        <a href="<?php echo e(url('/collections')); ?>" class="btn btn-primary">Acheter d'autres produits</a>
                    </div>

                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/thank-you.blade.php ENDPATH**/ ?>