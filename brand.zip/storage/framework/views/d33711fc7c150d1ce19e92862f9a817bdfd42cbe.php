<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Modifier un nouvel utilisateur'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        <div class="card shadow">
            <div class="card-header">
                <h4>Mise à jour des utilisateurs
                    <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-primary float-end btn-sm text-white" title="Retourne à la liste"><i class="mdi mdi-arrow-left"></i></a>
                </h4>
            </div>
            <div class="card-body">


                <form action="<?php echo e(url('admin/users/'.$getUser->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Nom</label>
                            <input type="text" value="<?php echo e($getUser->nom); ?>" name="nom" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Prénom</label>
                            <input type="text" value="<?php echo e($getUser->prenom); ?>" name="prenom" class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" value="<?php echo e($getUser->email); ?>" name="email" readonly class="form-control">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Mot de Passe</label>
                            <input type="text" value="" name="password" class="form-control">
                        </div>
                        

                        <div class="col-md-6 mb-3">
                            <label>Selectionner un rôle</label>
                            <select name="role_as" class="form-select">
                                <option value="">Choisir</option>
                                <option value="0" <?php echo e($getUser->role_as == '0' ? 'selected' : ''); ?>>Normal User</option>
                                <option value="1"<?php echo e($getUser->role_as == '1' ? 'selected' : ''); ?>>Administrateur</option>
                            </select>
                        </div>
                        <div class="col-md-12 text-end">
                            <button type="submit" class="btn btn-success">Valider</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>