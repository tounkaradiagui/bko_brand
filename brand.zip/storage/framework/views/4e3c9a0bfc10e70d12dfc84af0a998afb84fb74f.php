<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismiss" role="alert">
    <button class="close" type="button" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong >Félicitation ! </strong>

    <?php echo e(session('success')); ?>

</div>

<?php endif; ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger alert-dismiss" role="alert">
    <button class="close" type="button" data-dismiss="alert">
        <i class="fa fa-times"></i>
    </button>
    <strong >Erreur ! </strong>

    <?php echo e(session('error')); ?>

</div>

<?php endif; ?>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/layouts/alert.blade.php ENDPATH**/ ?>