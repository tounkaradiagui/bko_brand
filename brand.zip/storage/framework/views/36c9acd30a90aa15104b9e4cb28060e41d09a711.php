
<?php $__env->startSection('title', 'Mes commandes'); ?>
<?php $__env->startSection('content'); ?>

<div class="py-3 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="shadow bg-white p-3">
                    <h4>Mes commandes</h4>
                    <hr>
                    <div clqss="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Id commande</th>
                                    <th>Numéro de commande</th>
                                    <th>Nom</th>
                                    <th>Prénom</th>
                                    <th>Mode de Paiement</th>
                                    <th>Date de la commande</th>
                                    <th>Status de Message</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($items->id); ?></td>
                                    <td><?php echo e($items->tracking_no); ?></td>
                                    <td><?php echo e($items->nom); ?></td>
                                    <td><?php echo e($items->prenom); ?></td>
                                    <td><?php echo e($items->payment_mode); ?></td>
                                    <td><?php echo e($items->created_at->format('d-m-Y')); ?></td>
                                    <td><?php echo e($items->status_message); ?></td>
                                    <td><a href="<?php echo e(url('orders/'.$items->id)); ?>" class="btn btn-primary btn-sm">Voir</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" >Aucune commande disponible</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div>
                            <?php echo e($commandes->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/orders/index.blade.php ENDPATH**/ ?>