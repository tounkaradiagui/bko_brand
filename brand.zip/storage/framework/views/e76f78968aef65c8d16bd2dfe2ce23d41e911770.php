<div>
   

    <div class="py-3 py-md-5 bg-light">
        <div class="container">
    
            <div class="row">
                <div class="col-md-12">
                    <div class="shopping-cart">

                        <div class="cart-header d-none d-sm-none d-mb-block d-lg-block">
                            <div class="row">
                                <div class="col-md-6">
                                    <h4>Produits</h4>
                                </div>
                                <div class="col-md-2">
                                    <h4>Prix</h4>
                                </div>
                                
                                <div class="col-md-2">
                                    <h4>Supprimer</h4>
                                </div>
                            </div>
                        </div>

                        <?php $__empty_1 = true; $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlistItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if($wishlistItem->product): ?>
                            
                            <div class="cart-item">
                                <div class="row">
                                    <div class="col-md-6 my-auto">
                                        <a href="<?php echo e(url('collections/'.$wishlistItem->product->category->slug.'/'.$wishlistItem->product->slug)); ?>">
                                            <label class="product-name">
                                                <img src="<?php echo e($wishlistItem->product->productImages[0]->image); ?>" style="width: 50px; height: 50px" alt="  <?php echo e($wishlistItem->product->nom); ?>">
                                                <?php echo e($wishlistItem->product->nom); ?>

                                            </label>
                                        </a>
                                    </div>
                                    <div class="col-md-2 my-auto">
                                        <label class="price">$<?php echo e($wishlistItem->product->prix_de_vente); ?> </label>
                                    </div>
                                    
                                    <div class="col-md-2 col-5 my-auto">
                                        <div class="remove">
                                            <button type="button" wire:click="removeWishlist(<?php echo e($wishlistItem->id); ?>)" class="btn btn-danger btn-sm">
                                                <span wire:loading.remove wire:target="removeWishlist(<?php echo e($wishlistItem->id); ?>)">
                                                    <i class="fa fa-trash"></i> Supprimer
                                                </span>

                                                <span wire:loading wire:target="removeWishlist(<?php echo e($wishlistItem->id); ?>)">
                                                    <i class="fa fa-trash"></i>
                                                    En cours de suppression...
                                                </span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h4>Pas de favoris ajouté</h4>
                        <?php endif; ?>
                                
                    </div>
                </div>
            </div>

        </div>
    </div>


</div>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/livewire/frontend/wishlist-show.blade.php ENDPATH**/ ?>