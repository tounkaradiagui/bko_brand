<?php $__env->startSection('title', 'Les détails de ma commande'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success mb-3"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h3 class="pb-3">Les détails de la commande
                    <a href="<?php echo e(url('admin/orders')); ?>">
                        <span class="mdi mdi-arrow-left btn btn-danger float-end ml-2 btn-sm"> Back</span>
                    </a>
                    <a href="<?php echo e(url('admin/invoice/'.$order->id.'/generate')); ?>">
                        <span class="mdi mdi-arrow-down btn btn-success btn-sm float-end ml-2">Télécharger la facture</span>
                    </a>
                    <a href="<?php echo e(url('admin/invoice/'.$order->id)); ?>" target="_blank">
                        <span class="mdi mdi-eye btn btn-primary float-end ml-2 btn-sm" > Voir la facture</span>
                    </a>
                    <a href="<?php echo e(url('admin/invoice/'.$order->id.'/mail')); ?>">
                        <span class="mdi mdi-arrow-up btn btn-info float-end ml-2 btn-sm" > Envoyer la facture par Mail</span>
                    </a>
                </h3>
            </div>
            <div class="card-body">

                <div class="row">
                    <div class="col-md-6">
                        <h5>Détail de la commande</h5>
                        <hr>
                        <h6>Id de la commande : <?php echo e($order->id); ?></h6>
                        <h6>Numéro de la commande : <?php echo e($order->tracking_no); ?></h6>
                        <h6>Date de la commande : <?php echo e($order->created_at->format('d-m-Y h:i A')); ?></h6>
                        <h6>Mode de Paiement : <?php echo e($order->payment_mode); ?></h6>
                        <h6 class="border p-2 text-success">
                            Status de la commande :
                            <span class="text-uppercase"><?php echo e($order->status_message); ?></span>
                        </h6>
                    </div>

                    <div class="col-md-6">
                        <h5>Détail de l'utilisateur</h5>
                        <hr>
                        <h6>Nom : <?php echo e($order->nom); ?></h6>
                        <h6>Prénom : <?php echo e($order->prenom); ?></h6>
                        <h6>Email : <?php echo e($order->email); ?></h6>
                        <h6>Numéro de Téléphone : <?php echo e($order->phone); ?></h6>
                        <h6>Code Pin : <?php echo e($order->pincode); ?></h6>
                        <h6>Adresse : <?php echo e($order->adresse); ?></h6>
                    </div>
                </div>
                <br>
                <h5>Article commandé</h5>
                <hr>
                <div clqss="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Id de l'article</th>
                                <th>Image</th>
                                <th>Produit</th>
                                <th>Prix</th>
                                <th>Quantité</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $totalPrice = 0;
                            ?>
                            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="10%"><?php echo e($Orderitem->id); ?></td>
                                <td width="10%">
                                    <?php if($Orderitem->product->productImages): ?>
                                        <img src="<?php echo e(asset($Orderitem->product->productImages[0]->image)); ?>" style="width: 50px; height: 50px" alt="<?php echo e($Orderitem->product->nom); ?>">
                                    <?php else: ?>
                                        <img src="" style="width: 50px; height: 50px" alt="">
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <?php echo e($Orderitem->product->nom); ?>

                                    <?php if($Orderitem->productColor): ?>
                                        <?php if($Orderitem->productColor->color): ?>
                                            <span>- Couleur: <?php echo e($Orderitem->productColor->color->nom_couleur); ?></span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td width="10%"><?php echo e($Orderitem->product->prix_de_vente); ?> F CFA</td>
                                <td width="10%"><?php echo e($Orderitem->quantity); ?></td>
                                <td class="fw-bold"><?php echo e($Orderitem->quantity * $Orderitem->product->prix_de_vente); ?> F CFA</td>
                                <?php
                                    $totalPrice += $Orderitem->quantity * $Orderitem->product->prix_de_vente;
                                ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr >
                                <td colspan="5" class="fw-bold bg-dark text-white">Montant total</td>
                                <td colspan="1"  class="fw-bold bg-dark text-white"><?php echo e($totalPrice); ?> F CFA</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>

        <div class="card border mt-3">
            <div class="card-body">
                <h4>Processus de commande</h4>
                <hr>
                <div class="row">
                    <div class="col-md-5">
                        <form action="<?php echo e(url('admin/orders/'.$order->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <label>Modifier le status de la commande</label>
                            <div class="input-group">
                                <select name="order_status" class="form-select">
                                    <option value="">Selectionner un status</option>
                                    <option value="Commande en cours" <?php echo e(Request::get('status') == 'Commande en cours' ? 'selected' : ''); ?>>En cours</option>
                                    <option value="validee" <?php echo e(Request::get('status') == 'validee' ? 'selected' : ''); ?>>Valider</option>
                                    <option value="annuler" <?php echo e(Request::get('status') == 'annuler' ? 'selected' : ''); ?>>Annulée</option>
                                    <option value="livree" <?php echo e(Request::get('status') == 'livree' ? 'selected' : ''); ?>>Livrée</option>
                                </select>
                                <button type="submit" class="btn btn-primary text-white">Validée</button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-7">
                        <br/>
                        <h4 class="mt-3">Status actuel de la commande : <span class="text-uppercase"><?php echo e($order->status_message); ?></span> </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/orders/view.blade.php ENDPATH**/ ?>