<div class="d-inline">
    <?php echo e($cartCount); ?>

</div>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/livewire/frontend/cart/cart-count.blade.php ENDPATH**/ ?>