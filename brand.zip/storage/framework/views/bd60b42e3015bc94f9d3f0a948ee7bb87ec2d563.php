<?php $__env->startSection('title', "Inscription - Nouvel utilisateur !"); ?>
<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.signup', [])->html();
} elseif ($_instance->childHasBeenRendered('PXidnDO')) {
    $componentId = $_instance->getRenderedChildComponentId('PXidnDO');
    $componentTag = $_instance->getRenderedChildComponentTagName('PXidnDO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PXidnDO');
} else {
    $response = \Livewire\Livewire::mount('frontend.signup', []);
    $html = $response->html();
    $_instance->logRenderedChild('PXidnDO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/signup/index.blade.php ENDPATH**/ ?>