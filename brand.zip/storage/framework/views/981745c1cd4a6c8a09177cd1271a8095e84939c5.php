<?php $__env->startSection('title', 'Messages'); ?>
<?php $__env->startSection('content'); ?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.navbar.message-show', [])->html();
} elseif ($_instance->childHasBeenRendered('dqS9YIA')) {
    $componentId = $_instance->getRenderedChildComponentId('dqS9YIA');
    $componentTag = $_instance->getRenderedChildComponentTagName('dqS9YIA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dqS9YIA');
} else {
    $response = \Livewire\Livewire::mount('admin.navbar.message-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('dqS9YIA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/navbar/messages.blade.php ENDPATH**/ ?>