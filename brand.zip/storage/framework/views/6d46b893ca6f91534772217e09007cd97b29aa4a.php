

<?php $__env->startSection('title', 'Liste de Souhait'); ?>
<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.wishlist-show', [])->html();
} elseif ($_instance->childHasBeenRendered('7jD8rpU')) {
    $componentId = $_instance->getRenderedChildComponentId('7jD8rpU');
    $componentTag = $_instance->getRenderedChildComponentTagName('7jD8rpU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7jD8rpU');
} else {
    $response = \Livewire\Livewire::mount('frontend.wishlist-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('7jD8rpU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/wishlist/index.blade.php ENDPATH**/ ?>