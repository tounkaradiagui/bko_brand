<div class="main-navbar shadow-sm sticky-top">
        <div class="top-navbar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-1 my-auto d-none d-sm-none d-md-block d-lg-block">
                        <h5 class="brand-name"><?php echo e($appSetting->website_name ?? 'Diagui Shop'); ?></h5>
                    </div>
                    <div class="col-md-3 my-auto">
                        <form action="<?php echo e(url('rechercher')); ?>" method="get" role="search">
                            <div class="input-group">
                                <input type="search" name="rechercher" value="<?php echo e(Request::get('rechercher')); ?>" placeholder="Reherchez votre produit ici !" class="form-control" />
                                <button class="btn bg-white" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-8 my-auto">
                        <ul class="nav justify-content-end">

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('cart')); ?>">
                                    <i class="fa fa-shopping-cart"></i> Panier (<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.cart.cart-count', [])->html();
} elseif ($_instance->childHasBeenRendered('7MoumdW')) {
    $componentId = $_instance->getRenderedChildComponentId('7MoumdW');
    $componentTag = $_instance->getRenderedChildComponentTagName('7MoumdW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7MoumdW');
} else {
    $response = \Livewire\Livewire::mount('frontend.cart.cart-count', []);
    $html = $response->html();
    $_instance->logRenderedChild('7MoumdW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>)
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('wishlist')); ?>">
                                    <i class="fa fa-heart"></i> Favoris (<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.wishlist-count', [])->html();
} elseif ($_instance->childHasBeenRendered('Nq8gxmw')) {
    $componentId = $_instance->getRenderedChildComponentId('Nq8gxmw');
    $componentTag = $_instance->getRenderedChildComponentTagName('Nq8gxmw');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Nq8gxmw');
} else {
    $response = \Livewire\Livewire::mount('frontend.wishlist-count', []);
    $html = $response->html();
    $_instance->logRenderedChild('Nq8gxmw', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>)
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/contact')); ?>">
                                     Contact
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/a-propos-de-nous')); ?>">
                                     A Propos
                                </a>
                            </li>

                            <?php if(auth()->guard()->guest()): ?>
                                <?php if(Route::has('login')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Connexion')); ?></a>
                                    </li>
                                <?php endif; ?>

                                <?php if(Route::has('register')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Inscription')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa fa-user"></i> <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?>

                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="<?php echo e(url('monProfil')); ?>"><i class="fa fa-user"></i> Profile</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('admin/dashboard')); ?>" target="_blank"><i class="mdi mdi-speedometer"></i> Dashboard</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('orders')); ?>"><i class="fa fa-list"></i> Mes Commandes</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('wishlist')); ?>"><i class="fa fa-heart"></i> Mes Favoris</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(url('cart')); ?>"><i class="fa fa-shopping-cart"></i> Mon Panier</a></li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out"></i> <?php echo e(__('Déconnexion')); ?>

                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                             <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand d-block d-sm-block d-md-none d-lg-none" href="#">
                    Diagui Shop
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/collections')); ?>">Catégories</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/nouveaux-arrives')); ?>">Nouveautés</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/produits-populaire')); ?>">Produits populaire</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Electronique</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Fashions</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Accessoires</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Appareils électroménagers</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/layouts/inc/frontend/navbar.blade.php ENDPATH**/ ?>