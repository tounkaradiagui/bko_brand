<div class="d-inline">
    <?php echo e($wishlistCount); ?>

</div>

<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/livewire/frontend/wishlist-count.blade.php ENDPATH**/ ?>