<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'A Propos'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12 mt-3">
            <h3>Qui sommes-Nous ?</h3>

            <h5>
                Diagui-Shop.com est une boutique en ligne complète qui propose une large sélection
                de produits de qualité supérieure pour répondre à tous vos besoins en matière de shopping
                en ligne. Notre site est facile à naviguer et offre une expérience utilisateur conviviale pour vous aider
                à trouver rapidement ce que vous cherchez.
            </h5>
            <h5 class="mt-2">
                Sur Diagui Shop vous avez le choix entre payer votre commande à la livraison ou payer
                directement en ligne avec votre compte paypal (paiement sécurisé).
            </h5>
        </div>

        <div class="col-md-12 mt-3">
            <h3>Notre Engagement envers nos clients</h3>
            <h5>
                En tant qu'une boutique en ligne qui s'engage à fournir à ses clients des produits de qualité
                supérieure et une expérience d'achat en ligne exceptionnelle.
                Notre engagement envers nos clients est fondé sur plusieurs valeurs clés.
            </h5>

            <h4>
                Tout d'abord, nous nous engageons à offrir à nos clients des produits de qualité supérieure provenant des meilleures marques du marché.
            </h4>
            <h5 class="mt-3">
                <i class="fa fa-check"></i>
                Nous avons un processus de sélection rigoureux pour les produits que nous proposons, en veillant à ce que chaque article réponde à nos
                normes de qualité avant d'être mis en vente sur notre site.
            </h5>

            <h5 class="mt-3">
                <i class="fa fa-check"></i>
                Nous nous engageons également à offrir des prix abordables à nos clients, sans compromettre la qualité. Nous cherchons constamment des moyens de
                réduire les coûts pour que nous puissions proposer des produits de qualité supérieure à des prix compétitifs.
            </h5>

            <h5 class="mt-3">
                <i class="fa fa-check"></i>
                Nous sommes également engagés envers la satisfaction de nos clients. Nous croyons que chaque client mérite une expérience d'achat en ligne exceptionnelle,
                et nous faisons tout notre possible pour répondre aux besoins de nos clients. Nous offrons un service clientèle exceptionnel,
                prêt à aider les clients à chaque étape de leur achat, et nous avons une politique de retour flexible pour que nos clients puissent acheter en toute confiance.
            </h5>

            <h5 class="mt-3">
                <i class="fa fa-check"></i>
                Enfin, nous sommes engagés envers l'innovation et l'amélioration continue. Nous cherchons constamment des moyens d'améliorer notre site web, nos processus
                et nos offres de produits pour offrir à nos clients la meilleure expérience de shopping en ligne possible.
            </h5>



            <h5 class="mt-3">
                En grosso-modo, notre engagement envers nos clients est fondé sur la qualité, la valeur, la satisfaction et l'innovation. Nous sommes déterminés à offrir à nos clients
                une expérience de shopping en ligne exceptionnelle et à leur fournir des produits de qualité supérieure à des prix compétitifs.
            </h5>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/pages/about.blade.php ENDPATH**/ ?>