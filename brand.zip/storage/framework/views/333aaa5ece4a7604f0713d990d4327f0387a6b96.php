
<?php $__env->startSection('title', 'Les détails de ma commande'); ?>
<?php $__env->startSection('content'); ?>

<div class="py-3 py-md-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="shadow bg-white p-3">
                    <h4>
                        <i class="fa fa-shopping-cart text-dark"> Les détails de ma commande</i>
                        <a href="<?php echo e(url('orders')); ?>">
                            <i class="fa fa-arrow-left btn btn-danger float-end"> Back</i>
                        </a>
                    </h4>
                    <hr>
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Détail de la commande</h5>
                            <hr>
                            <h6>Id de la commande : <?php echo e($orders->id); ?></h6>
                            <h6>Numéro de la commande : <?php echo e($orders->tracking_no); ?></h6>
                            <h6>Date de la commande : <?php echo e($orders->created_at->format('d-m-Y h:i A')); ?></h6>
                            <h6>Mode de Paiement : <?php echo e($orders->payment_mode); ?></h6>
                            <h6 class="border p-2 text-success">
                                Status de la commande : 
                                <span class="text-uppercase"><?php echo e($orders->status_message); ?></span>
                            </h6>
                        </div>

                        <div class="col-md-6">
                            <h5>Détail de l'utilisateur</h5>
                            <hr>
                            <h6>Nom : <?php echo e($orders->nom); ?></h6>
                            <h6>Prénom : <?php echo e($orders->prenom); ?></h6>
                            <h6>Email : <?php echo e($orders->email); ?></h6>
                            <h6>Numéro de Téléphone : <?php echo e($orders->phone); ?></h6>
                            <h6>Code Pin : <?php echo e($orders->pincode); ?></h6>
                            <h6>Adresse : <?php echo e($orders->adresse); ?></h6>
                        </div>
                    </div>
                    <br>
                    <h5>Article commandé</h5>
                    <hr>
                    <div clqss="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Id de l'article</th>
                                    <th>Image</th>
                                    <th>Produit</th>
                                    <th>Prix</th>
                                    <th>Quantité</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $totalPrice = 0;
                                ?>
                                <?php $__currentLoopData = $orders->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="10%"><?php echo e($items->id); ?></td>
                                    <td width="10%">
                                        <?php if($items->product->productImages): ?>
                                            <img src="<?php echo e(asset($items->product->productImages[0]->image)); ?>" style="width: 50px; height: 50px" alt="<?php echo e($items->product->nom); ?>">
                                        <?php else: ?>
                                            <img src="" style="width: 50px; height: 50px" alt="">
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php echo e($items->product->nom); ?>

                                        <?php if($items->productColor): ?>
                                            <?php if($items->productColor->color): ?>
                                                <span>- Couleur: <?php echo e($items->productColor->color->nom_couleur); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td width="10%"><?php echo e($items->product->prix_de_vente); ?> F CFA</td>
                                    <td width="10%"><?php echo e($items->quantity); ?></td>
                                    <td class="fw-bold"><?php echo e($items->quantity * $items->product->prix_de_vente); ?> F CFA</td>
                                    <?php
                                        $totalPrice += $items->quantity * $items->product->prix_de_vente;
                                    ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-dark text-white">
                                    <td colspan="5" class="fw-bold">Montant total</td>
                                    <td colspan="1"  class="fw-bold"><?php echo e($totalPrice); ?> F CFA</td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/orders/view.blade.php ENDPATH**/ ?>