<?php $__env->startSection('title', 'Vérification - adresse - email'); ?>

<?php $__env->startSection('content'); ?>

hello

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/email/verification.blade.php ENDPATH**/ ?>