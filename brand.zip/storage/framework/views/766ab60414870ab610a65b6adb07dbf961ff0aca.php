<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Contacter Golden Market'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-show', [])->html();
} elseif ($_instance->childHasBeenRendered('e7ElaEY')) {
    $componentId = $_instance->getRenderedChildComponentId('e7ElaEY');
    $componentTag = $_instance->getRenderedChildComponentTagName('e7ElaEY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('e7ElaEY');
} else {
    $response = \Livewire\Livewire::mount('contact-show', []);
    $html = $response->html();
    $_instance->logRenderedChild('e7ElaEY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>