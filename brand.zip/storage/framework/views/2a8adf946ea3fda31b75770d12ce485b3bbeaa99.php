<?php $__env->startSection('title', 'Bienvenue sur Golden market'); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">

        <div class="carousel-inner">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($key == '0' ? 'active' : ''); ?>">
                    <?php if('uploads/slider/'.$slider->image): ?>
                        <img src="<?php echo e(url('uploads/slider/'.$slider->image)); ?>" class="d-block w-100" alt="...">
                    <?php endif; ?>
                    <div class="carousel-caption d-none d-md-block">
                        <div class="custom-carousel-content">
                            <h1>
                                <span><?php echo $slider->title; ?> </span>
                            </h1>
                            <p>
                                <?php echo $slider->description; ?>

                            </p>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Précédent</span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Suivant</span>
        </button>
    </div>

    <div class="py-5 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-8 text-center">
                    <h3>Bienvenue sur Diagui Shop</h3>
                </div>
                <div class="underline mx-auto"></div>
                

            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-header bg-primary"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>
                        En Tendance
                    </h4>
                    <div class="underline mb-4"></div>
                </div>
                <?php if($trendingProducts): ?>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme four-carousel">
                        <?php $__currentLoopData = $trendingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="product-card">
                                <div class="product-card-img">
                                    <label class="stock bg-danger">Nouveau</label>
                                    <?php if($produit->productImages->count() > 0): ?>
                                    <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <img src="<?php echo e(asset($produit->productImages[0]->image)); ?>" alt="<?php echo e($produit->nom); ?>">
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <div class="product-card-body">
                                    <p class="product-brand"><?php echo e($produit->marque); ?></p>
                                    <h5 class="product-name">
                                        <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <?php echo e($produit->nom); ?>

                                        </a>
                                    </h5>
                                    <div>
                                        <span class="selling-price">$<?php echo e($produit->prix_de_vente); ?></span>
                                        <span class="original-price">$<?php echo e($produit->prix_original); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                 <?php else: ?>
                <div class="col-md-12">
                    <div class="p-2">
                        <h4>
                            Pas de Produits disponible
                        </h4>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-header bg-primary"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="py-5 bg-white">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>
                        Nouveautés
                        <a href="<?php echo e(url('/nouveaux-arrives')); ?>" class="btn btn-primary btn-sm float-end">Voir Plus</a>
                    </h4>
                    <div class="underline mb-4"></div>
                </div>
                <?php if($news): ?>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme four-carousel">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="product-card">
                                <div class="product-card-img">
                                    <label class="stock bg-danger">Nouveau</label>
                                    <?php if($produit->productImages->count() > 0): ?>
                                    <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <img src="<?php echo e(asset($produit->productImages[0]->image)); ?>" alt="<?php echo e($produit->nom); ?>">
                                    </a>
                                    
                                    <?php endif; ?>
                                </div>
                                <div class="product-card-body">
                                    <p class="product-brand"><?php echo e($produit->marque); ?></p>
                                    <h5 class="product-name">
                                        <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <?php echo e($produit->nom); ?>

                                        </a>
                                    </h5>
                                    <div>
                                        <span class="selling-price">$<?php echo e($produit->prix_de_vente); ?></span>
                                        <span class="original-price">$<?php echo e($produit->prix_original); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                 <?php else: ?>
                <div class="col-md-12">
                    <div class="p-2">
                        <h4>
                            Pas de Nouveautés disponible
                        </h4>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-header bg-primary"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4>
                        Populaire
                        <a href="<?php echo e(url('/produits-populaire')); ?>" class="btn btn-primary btn-sm float-end">Voir Plus</a>
                    </h4>
                    <div class="underline mb-4"></div>
                </div>
                <?php if($featured): ?>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme four-carousel">
                        <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="product-card">
                                <div class="product-card-img">
                                    <label class="stock bg-danger">Nouveau</label>
                                    <?php if($produit->productImages->count() > 0): ?>
                                    <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <img src="<?php echo e(asset($produit->productImages[0]->image)); ?>" alt="<?php echo e($produit->nom); ?>">
                                    </a>
                                    
                                    <?php endif; ?>
                                </div>
                                <div class="product-card-body">
                                    <p class="product-brand"><?php echo e($produit->marque); ?></p>
                                    <h5 class="product-name">
                                        <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                        <?php echo e($produit->nom); ?>

                                        </a>
                                    </h5>
                                    <div>
                                        <span class="selling-price">$<?php echo e($produit->prix_de_vente); ?></span>
                                        <span class="original-price">$<?php echo e($produit->prix_original); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                 <?php else: ?>
                <div class="col-md-12">
                    <div class="p-2">
                        <h4>
                            Pas de Produits Populaire disponible
                        </h4>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card shadow">
                        <div class="card-header bg-primary"></div>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('.four-carousel').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:4
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/index.blade.php ENDPATH**/ ?>