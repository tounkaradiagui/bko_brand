<?php $__env->startSection('title', 'Mon Profil'); ?>
<?php $__env->startSection('content'); ?>

<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-md-10">
                <h4>
                    Mon Profil
                    <a href="<?php echo e(url('my-password')); ?>" class="btn text-white btn-danger float-end">Changer mon mot de passe ?</a>
                </h4>
                <div class="underline mb-4"></div>
            </div>

            <div class="col-md-10">
                <div class="card shadow">
                    <div class="card-header bg-primary">
                        <h4 class="mb-0 text-white">
                            Détails de l'utilisateur
                        </h4>
                    </div>

                    <div class="card-body">
                        <form action="<?php echo e(url('monProfil')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Nom</label>
                                        <input type="text" value="<?php echo e(Auth::user()->nom); ?>" name="nom" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Prénom</label>
                                        <input type="text" value="<?php echo e(Auth::user()->prenom); ?>" name="prenom" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Date de Naissance</label>
                                        <input type="date" value="<?php echo e(Auth::user()->date_de_naissance); ?>" name="date_de_naissance" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Lieu de Naissance</label>
                                        <input type="lieu_de_naissance" value="<?php echo e(Auth::user()->lieu_de_naissance); ?>" name="lieu_de_naissance" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Email</label>
                                        <input type="email" readonly value="<?php echo e(Auth::user()->email); ?>" name="email" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label>Téléphone</label>
                                        <input type="text" value="<?php echo e(Auth::user()->telephone); ?>" name="telephone" class="form-control">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>Adresse</label>
                                        <textarea name="adresse" class="form-control" rows="3"><?php echo e(Auth::user()->adresse); ?></textarea>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label>Photo de Profil</label>
                                        <input type="file" name="image" class="form-control">
                                        <img src="<?php echo e(asset('uploads/profile/' .Auth::user()->image)); ?>" class="w-45" alt="" width="100px" height="100px">
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-primary float-end">Enregister</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/users/profile.blade.php ENDPATH**/ ?>