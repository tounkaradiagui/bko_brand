<?php $__env->startSection('title', 'Enregistrement de couleurs'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>L'ajout de couleurs
                    <a href="<?php echo e(url('admin/colors')); ?>" class="btn btn-danger float-end btn-sm text-white" title="Retour"><i class="mdi mdi-arrow-left"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/colors/create')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="">Nom de la couleur</label>
                        <input type="text" class="form-control" name="nom_couleur">
                    </div>
                    <div class="mb-3">
                        <label for="">Code de la couleur</label>
                        <input type="text" class="form-control" name="code_couleur">
                    </div>
                    <div class="mb-3">
                        <label for="">Status</label> <br>
                        <input type="checkbox" name="status"/> Cocher = Masquée, Décocher = Visible
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary btn-sm">Enregistrer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/colors/create.blade.php ENDPATH**/ ?>