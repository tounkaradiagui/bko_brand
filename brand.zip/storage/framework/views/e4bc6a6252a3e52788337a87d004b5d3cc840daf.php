<?php $__env->startSection('title', 'Liste de Produits'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>La liste de produits
                    <a href="<?php echo e(url('admin/products/create')); ?>" class="btn btn-primary float-end btn-sm text-white" title="Ajouter"><i class="mdi mdi-plus-circle"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-responsive-sm table-striped">
                    <thead>
                        <tr>
                            <th>Catégorie</th>
                            <th>Produits</th>
                            <th>Prix</th>
                            <th>Quantité</th>
                            <th>Status</th>
                            <th colspan="2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <?php if($product->category): ?>
                                    <?php echo e($product->category->name); ?>

                                <?php else: ?>
                                    Pas de catégorie
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($product->nom); ?></td>
                            <td><?php echo e($product->prix_de_vente); ?></td>
                            <td><?php echo e($product->quantity); ?></td>
                            <td><?php echo e($product->status == '1' ? 'Masqué':'Visible'); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/products/'.$product->id.'/edit')); ?>" class="btn btn-primary btn-sm" title="Modifier"><i class="mdi mdi-pen"></i></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/products/'.$product->id.'/delete')); ?>" onclick="return confirm('Voulez-vous vraiment supprimer ce produit ?')"
                                     class="btn btn-danger btn-sm" title="Supprimer"><i class="mdi mdi-delete"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">Aucun produit disponible</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/products/index.blade.php ENDPATH**/ ?>