<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta name="meta_description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('Diagui TOUNKARA'); ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/base/vendor.bundle.base.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
    <!-- le lien du bootstrap doit toujours etre au dessus du css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/style.css')); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/logogolden.png')); ?>" >

    

    <style>
        .form-control{
            border:1px solid #ddd;
        }

        .sidebar .nav .nav-item.active{
            background-color: #e9e9e9;
        }

    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>

    <div class="container-scroller">
        <?php echo $__env->make('layouts.inc.admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('layouts.inc.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">
                <div class="content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

        </div>
    </div>


    <script src="<?php echo e(asset('admin/vendors/base/vendor.bundle.base.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>

    

    <script src="<?php echo e(asset('admin/js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/template.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/data-table.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/dataTables.bootstrap4.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.7.x/dist/alpine.min.js" defer></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

    <?php echo $__env->yieldPushContent('script'); ?>;

</head>
<body>



<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/layouts/admin.blade.php ENDPATH**/ ?>