<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>L'ajout de sliders
                    <a href="<?php echo e(url('admin/sliders' )); ?>" class="btn btn-danger float-end btn-sm text-white" title="Retour"><i class="mdi mdi-arrow-left"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/sliders/'.$slider->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="">Titre</label>
                        <input type="text" class="form-control" value="<?php echo e($slider->title); ?>" name="title">
                    </div>

                    <div class="mb-3">
                        <label for="">Description</label>
                        <textarea class="form-control"  name="description" rows="3"><?php echo e($slider->description); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="">Image</label> <br>
                        <input type="file" class="form-control" name="image"/>
                        <img src="<?php echo e(asset('uploads/slider/' .$slider->image)); ?>" alt="slider" style="width:50px; height:50px;">
                    </div>

                    <div class="mb-3">
                        <label for="">Status</label> <br>
                        <input type="checkbox" <?php echo e($slider->status == '1' ? 'checked' : ''); ?> style="width:30px; height:30px;" name="status"/> checked = Hidden, Unchecked = Visible
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary btn-sm">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>