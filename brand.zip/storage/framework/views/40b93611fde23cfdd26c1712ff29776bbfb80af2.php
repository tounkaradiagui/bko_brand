<?php $__env->startSection('title', 'Liste de couleurs'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>La liste de couleurs
                    <a href="<?php echo e(url('admin/colors/create')); ?>" class="btn btn-primary float-end btn-sm text-white" title="Ajouter"><i class="mdi mdi-plus"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Nom de la couleur</th>
                            <th>Code couleur</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $couleurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($colors->nom_couleur); ?></td>
                            <td><?php echo e($colors->code_couleur); ?></td>
                            <td><?php echo e($colors->status ? 'Masquée':'Visible'); ?></td>
                            <td>
                                <a href="<?php echo e(url('admin/colors/'.$colors->id.'/edit')); ?>" class="btn btn-primary btn-sm" title="Modifier"><i class="mdi mdi-pen"></i></a>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/colors/'.$colors->id.'/delete')); ?>" onclick="return confirm('Voule-vous vraiment supprimé cette couleur ?')"
                                     class="btn btn-danger btn-sm" title="Supprimer"><i class="mdi mdi-delete"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/colors/index.blade.php ENDPATH**/ ?>