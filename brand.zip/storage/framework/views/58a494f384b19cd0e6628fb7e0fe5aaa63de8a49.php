<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" style="background-color: #2874f0;">
    <div class="navbar-brand-wrapper d-flex justify-content-center" style="background-color: #2874f0 ;">
        <div class="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100" >
            <a class="navbar-brand brand-logo text-white" href="<?php echo e(url('/')); ?>">
                <!-- <img src="<?php echo e(asset('admin/images/logogolden.png')); ?>" alt="logo"/> -->
                Diagui Shop
            </a>
            <a class="navbar-brand brand-logo-mini" href="<?php echo e(url('admin/dashboard')); ?>">
                <!-- <img src="<?php echo e(asset('admin/images/logogolden.png')); ?>" alt="logo"/> -->
            </a>
            <button class="navbar-toggler navbar-toggler align-self-center text-white" type="button" data-toggle="minimize">
                <span class="mdi mdi-sort-variant"></span>
            </button>
        </div>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end" style="background-color: #2874f0; color:#fff;">
        
        <ul class="navbar-nav navbar-nav-right" >
            <li class="nav-item dropdown me-1">
                <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center" id="messageDropdown" href="<?php echo e(url('admin/messages')); ?>" data-bs-toggle="dropdown">
                    <i class="mdi mdi-message-text mx-0"></i>
                    
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">

                    <a class="dropdown-item" href="<?php echo e(url('admin/messages')); ?>">
                        Répondre les e-mail
                    </a>

                </div>
            </li>
            <li class="nav-item dropdown me-4">
                <a class="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown" id="notificationDropdown" href="#" data-bs-toggle="dropdown">
                    <i class="mdi mdi-bell mx-0"></i>
                    
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="notificationDropdown">
                    <a class="dropdown-item" href="<?php echo e(url('admin/messages')); ?>">
                        Voir les notifications
                    </a>

                </div>
            </li>
            <li class="nav-item nav-profile dropdown" >
                <a class="nav-link dropdown-toggle text-white" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                    <img src="<?php echo e(asset('uploads/profile/' .Auth::user()->image)); ?>" alt="profile"/>
                    <span class="nav-profile-name text-white"><?php echo e(Auth::user()->prenom); ?> <?php echo e(Auth::user()->nom); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                    

                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        <i class="mdi mdi-logout text-primary"></i><?php echo e(__('Déconnexion')); ?>

                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center " type="button" data-toggle="offcanvas">
            <span class="mdi text-white mdi-menu "></span>
        </button>
    </div>
</nav>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/layouts/inc/admin/navbar.blade.php ENDPATH**/ ?>