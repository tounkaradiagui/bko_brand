<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>L'ajout de couleurs
                    <a href="<?php echo e(url('admin/colors')); ?>" class="btn btn-danger float-end btn-sm text-white" title="Retour"><i class="mdi mdi-arrow-left"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/colors/'.$color->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="">Nom de la couleur</label>
                        <input type="text" class="form-control" value="<?php echo e($color->nom_couleur); ?>" name="nom_couleur">
                    </div>
                    <div class="mb-3">
                        <label for="">Code de la couleur</label>
                        <input type="text" class="form-control" value="<?php echo e($color->code_couleur); ?>" name="code_couleur">
                    </div>
                    <div class="mb-3">
                        <label for="">Status</label> <br>
                        <input type="checkbox" <?php echo e($color->status ? 'checked':''); ?> name="status"/> Cocher = Masquée, Décocher = Visible
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary btn-sm">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/colors/edit.blade.php ENDPATH**/ ?>