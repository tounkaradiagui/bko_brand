<!DOCTYPE html>
<html lang="fr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Facture #<?php echo e($order->id); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('admin/images/logogolden.png')); ?>" >


    <style>
        html,
        body {
            margin: 10px;
            padding: 10px;
            font-family: sans-serif;
        }
        h1,h2,h3,h4,h5,h6,p,span,label {
            font-family: sans-serif;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 0px !important;
        }
        table thead th {
            height: 28px;
            text-align: left;
            font-size: 16px;
            font-family: sans-serif;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 14px;
        }

        .heading {
            font-size: 24px;
            margin-top: 12px;
            margin-bottom: 12px;
            font-family: sans-serif;
        }
        .small-heading {
            font-size: 18px;
            font-family: sans-serif;
        }
        .total-heading {
            font-size: 18px;
            font-weight: 700;
            font-family: sans-serif;
        }
        .order-details tbody tr td:nth-child(1) {
            width: 20%;
        }
        .order-details tbody tr td:nth-child(3) {
            width: 20%;
        }

        .text-start {
            text-align: left;
        }
        .text-end {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .company-data span {
            margin-bottom: 4px;
            display: inline-block;
            font-family: sans-serif;
            font-size: 14px;
            font-weight: 400;
        }
        .no-border {
            border: 1px solid #fff !important;
        }
        .bg-blue {
            background-color: #414ab1;
            color: #fff;
        }
    </style>
</head>
<body>

    <table class="order-details">
        <thead>
            <tr>
                <th width="50%" colspan="2">
                    <h2 class="text-start"><?php echo e($appSetting->website_name ?? "Diagui Shop"); ?></h2>
                </th>
                <th width="50%" colspan="2" class="text-end company-data">
                    <span>Facture #<?php echo e($order->id); ?></span> <br>
                    <span>Date : <?php echo e($order->created_at->format('d-m-Y h:i A')); ?></span> <br>
                    <span>Zip code : <?php echo e($order->pincode); ?></span> <br>
                    <span>Adresse: <?php echo e($order->adresse); ?></span> <br>
                </th>
            </tr>
            <tr class="bg-blue">
                <th width="50%" colspan="2">Détails de la commande</th>
                <th width="50%" colspan="2">Détails de l'utilisateur</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Identifiant:</td>
                <td><?php echo e($order->id); ?></td>

                <td>Nom complet:</td>
                <td><?php echo e($order->nom); ?> <?php echo e($order->prenom); ?></td>

            </tr>
            <tr>
                <td>Numéro:</td>
                <td><?php echo e($order->tracking_no); ?></td>

                <td>Email:</td>
                <td><?php echo e($order->email); ?></td>
            </tr>
            <tr>
                <td>Date:</td>
                <td><?php echo e($order->created_at->format('d-m-Y h:i A')); ?></td>

                <td>Numéro de Téléphone:</td>
                <td><?php echo e($order->phone); ?></td>
            </tr>
            <tr>
                <td>Mode Paiment:</td>
                <td><?php echo e($order->payment_mode); ?></td>

                <td>Adresse:</td>
                <td><?php echo e($order->adresse); ?></td>
            </tr>
            <tr>
                <td>Status de la commande:</td>
                <td><?php echo e($order->status_message); ?></td>

                <td>Pin code:</td>
                <td><?php echo e($order->pincode); ?></td>
            </tr>
        </tbody>
    </table>

    <table>
        <thead>
            <tr>
                <th class="no-border text-start heading" colspan="5">
                    Articles commandés
                </th>
            </tr>
            <tr class="bg-blue">
                <th>Identifiants</th>
                <th>Produits</th>
                <th>Prix</th>
                <th>Quantités</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $totalPrice = 0;
            ?>
            <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td width="10%"><?php echo e($Orderitem->id); ?></td>
                <td>
                    <?php echo e($Orderitem->product->nom); ?>

                    <?php if($Orderitem->productColor): ?>
                        <?php if($Orderitem->productColor->color): ?>
                            <span>- Couleur: <?php echo e($Orderitem->productColor->color->nom_couleur); ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td width="10%"><?php echo e($Orderitem->product->prix_de_vente); ?> F CFA</td>
                <td width="10%"><?php echo e($Orderitem->quantity); ?></td>
                <td class="fw-bold"><?php echo e($Orderitem->quantity * $Orderitem->product->prix_de_vente); ?> F CFA</td>
                <?php
                    $totalPrice += $Orderitem->quantity * $Orderitem->product->prix_de_vente;
                ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="bg-blue">
                <td colspan="4" class="total-heading">Montant total</td>
                <td colspan="1"  class="total-heading"><?php echo e($totalPrice); ?> F CFA</td>
            </tr>
        </tbody>
    </table>

    <br>
    <p class="text-center">
        Merci d'avoir choisi Diagui Shop
    </p>

</body>
</html>
<?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/invoice/generate-invoice.blade.php ENDPATH**/ ?>