

<?php $__env->startSection('title'); ?>
<?php echo e($product->meta_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keyword'); ?>
<?php echo e($product->meta_keyword); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?>
<?php echo e($product->meta_description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.product.view', ['category' => $category,'product' => $product])->html();
} elseif ($_instance->childHasBeenRendered('KVhBBTi')) {
    $componentId = $_instance->getRenderedChildComponentId('KVhBBTi');
    $componentTag = $_instance->getRenderedChildComponentTagName('KVhBBTi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KVhBBTi');
} else {
    $response = \Livewire\Livewire::mount('frontend.product.view', ['category' => $category,'product' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('KVhBBTi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/collections/products/view.blade.php ENDPATH**/ ?>