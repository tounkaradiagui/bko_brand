

<?php $__env->startSection('title', 'Produits Populaire'); ?>
<?php $__env->startSection('content'); ?>

<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4>Produits Populaire</h4>
                <div class="underline mb-4"></div>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>               
                <div class="col-md-3">
                    <div class="product-card">
                        <div class="product-card-img">
                            <label class="stock bg-danger">En Vedette</label>
                            <?php if($produit->productImages->count() > 0): ?>
                            <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                <img src="<?php echo e(asset($produit->productImages[0]->image)); ?>" alt="<?php echo e($produit->nom); ?>">
                            </a>
                            
                            <?php endif; ?>
                        </div>
                        <div class="product-card-body">
                            <p class="product-brand"><?php echo e($produit->marque); ?></p>
                            <h5 class="product-name">
                                <a href="<?php echo e(url('/collections/'.$produit->category->slug.'/'.$produit->slug)); ?> ">
                                <?php echo e($produit->nom); ?> 
                                </a>
                            </h5>
                            <div>
                                <span class="selling-price">$<?php echo e($produit->prix_de_vente); ?></span>
                                <span class="original-price">$<?php echo e($produit->prix_original); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-md-12 p-2">
                    <h4>
                        Pas de Produits Populaire  disponible
                    </h4>
                </div>
            <?php endif; ?>

            <div>
                <a href="<?php echo e(url('/collections')); ?>" class="btn btn-primary btn-sm px-3">Achetez Plus</a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/frontend/pages/featured-product.blade.php ENDPATH**/ ?>