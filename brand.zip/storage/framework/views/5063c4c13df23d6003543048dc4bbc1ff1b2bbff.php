<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Gestion des utilisateurs'); ?>

<div class="row">
    <div class="col-md-12">
        <?php if(session('message')): ?>
            <div class="alert alert-success"><?php echo e((session('message'))); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h4>La liste des utilisateurs || En ligne :
                    <?php $user_total = "0"; ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users_total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        if($users_total->isUserOnline())
                        {
                            $user_total = $user_total + 1;
                        }
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($user_total); ?>

                    <a href="<?php echo e(url('admin/users/create')); ?>" class="btn btn-primary float-end btn-sm text-white" title="Ajouter un nouvel utilisateur"><i class="mdi mdi-plus-circle"></i></a>
                </h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-responsive table-striped display">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Adresse</th>
                            <th>Role</th>
                            <th>Statut</th>
                            <th>Connectivité</th>
                            <th colspan="2" class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($user->nom); ?></td>
                            <td><?php echo e($user->prenom); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->telephone); ?></td>
                            <td><?php echo e($user->adresse); ?></td>
                            <td>
                                <?php if($user->role_as == '0'): ?>
                                    <label class="badge badge-primary">Normal User</label>
                                <?php elseif($user->role_as == '1'): ?>
                                    <label class="badge badge-success">Administrateur</label>
                                <?php else: ?>
                                    <label class="badge badge-warning">Aucun rôle assigné</label>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->statut == 0): ?>
                                    <span class="badge badge-danger">Inactif</span>
                                <?php elseif($user->statut == 1): ?>
                                    <span class="badge badge-success">Actif</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($user->isUserOnline()): ?>
                                    <span class="badge badge-success">En ligne</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Déconnecté</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/users/'.$user->id.'/edit')); ?>" class="btn btn-primary btn-sm" title="Modifier ?"><i class="mdi mdi-pen"></i></a>
                            </td>
                            <td>
                               <?php if($user->statut == 1): ?>
                                <a href="<?php echo e(route('users.status', ['user_id' => $user->id, 'status_code' => 0 ])); ?>" class="btn-sm btn btn-danger m-2" title="Desactiver cet utilisateur">
                                    <i class="mdi mdi-cancel" ></i>
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(route('users.status', ['user_id' => $user->id, 'status_code' => 1 ])); ?>" class="btn-sm btn btn-success m-2" title="Activer cet utilisateur">
                                    <i class="mdi mdi-check-circle" ></i>
                                </a>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/users/'.$user->id.'/delete')); ?>"
                                     onclick="return confirm('Voulez-vous vraiment supprimer cet utilisateur ?')"
                                class="btn btn-danger btn-sm" title="Supprimer ?"><i class="mdi mdi-delete"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7">Aucun utilisateur disponible</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ttec\Desktop\Bko brand\resources\views/admin/user/index.blade.php ENDPATH**/ ?>