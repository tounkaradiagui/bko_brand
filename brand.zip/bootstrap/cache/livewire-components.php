<?php return array (
  'admin.brand.index' => 'App\\Http\\Livewire\\Admin\\Brand\\Index',
  'admin.category.index' => 'App\\Http\\Livewire\\Admin\\Category\\Index',
  'admin.navbar.message-show' => 'App\\Http\\Livewire\\Admin\\Navbar\\MessageShow',
  'contact-show' => 'App\\Http\\Livewire\\ContactShow',
  'frontend.cart.cart-count' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartCount',
  'frontend.cart.cart-show' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartShow',
  'frontend.checkout.checkout-show' => 'App\\Http\\Livewire\\Frontend\\Checkout\\CheckoutShow',
  'frontend.product.index' => 'App\\Http\\Livewire\\Frontend\\Product\\Index',
  'frontend.product.view' => 'App\\Http\\Livewire\\Frontend\\Product\\View',
  'frontend.signup' => 'App\\Http\\Livewire\\Frontend\\Signup',
  'frontend.wishlist-count' => 'App\\Http\\Livewire\\Frontend\\WishlistCount',
  'frontend.wishlist-show' => 'App\\Http\\Livewire\\Frontend\\WishlistShow',
);